from django.urls import path

from . import views

urlpatterns = [
    path('shows/', views.shows),
    path('shows/new', views.newShow),
    path('submitShow', views.submitShow),
    path('shows/<int:num>', views.showInfo),
    path('shows/<int:num>/edit', views.editShow),
    path('shows/<int:num>/update', views.updateShow),
    path('shows/<int:num>/destroy', views.destroyShow),
]