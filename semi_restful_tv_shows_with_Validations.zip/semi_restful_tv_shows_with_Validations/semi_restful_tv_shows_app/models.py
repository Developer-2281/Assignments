from django.db import models
from datetime import date # make sure to import the date

# Create your models here

class ShowManager(models.Manager): #Show is the variable name I gave the manager, you can name it whatever you want.
    def Showvalidator(self, postData):
        errors = {}
        today = date.today()
        # add keys and values to errors dictionary for each invalid field
        if len(postData['title']) == 0:
            errors["titlelength"] = "Title is Required"
        elif len(postData['title']) < 2:
            errors["titlelength2char"] = "Title must be 2 or more characters"
        if len(postData['netname']) == 0:
            errors["networklength"] = "Network is Required"
        elif len(postData['netname']) < 3:
            errors["networklength3char"] = "Network must be three or more characters"
        if len(postData['desc']) == 0:
            errors["descriptionlength"] = "Description is Required"
        elif len(postData['desc']) < 10:
            errors["descriptionlength10char"] = "Description must be ten or more characters"
        if len(postData['rate']) == 0:
            errors["ratinglength"] = "Rating is Required"
        elif int(postData['rate']) < 0:
            errors["negativerating"] = "Rating cannot be a negative number"
        if len(postData['duration']) == 0:
            errors["durationlength"] = "Duration is Required"
        elif int(postData['duration']) < 10:
            errors["durationMin"] = "Duration needs to be 10 or more minutes"
        if len(postData['reldate']) == 0:
            errors["reldatelength"] = "A Release date is Required"
        elif postData['reldate'] > str(today):
            errors['cannotbeFutureDate'] = "Cannot post past the present"
        return errors
        # inside each function in the views file you need to add validation coding and the html.

class Show(models.Model):

    title = models.CharField(max_length=255)
    network = models.CharField(max_length=255)
    release_date = models.DateField()
    description = models.TextField()
    rating = models.IntegerField()
    duration = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = ShowManager() #***** Remember to add this for validations *****#

    def __str__(self):
	    return f"<Show object: {self.title} ({self.id})>"

