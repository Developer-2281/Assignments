from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages  #remember to add this for the validator
from .models import *
# Create your views here.

def shows(request):
    print(Show.objects.all())
    context = {
        'showdata' : Show.objects.all(),
    }
    return render(request, 'index.html', context)

def submitShow(request):
    print(request.POST)
    validationErrors = Show.objects.Showvalidator(request.POST)
    print("errors from validator are printed below")
    print(validationErrors)

    if len(validationErrors) > 0:
        for key, value in validationErrors.items():
            messages.error(request, value)
        return redirect("/shows/new")
    
    # to just create the show use the commented out code below.
    #Show.objects.create(title = request.POST['title'], network = request.POST['netname'], release_date = request.POST['reldate'], description = request.POST['desc'], rating = request.POST['rate'], duration = request.POST['duration'])
    
    #to redirect to the newly created show create a variable that will equal the show being created
    #then put that variable and .id into the redirected return as below in {} and an f string, notice it must match a path in urls

    show = Show.objects.create(title = request.POST['title'], network = request.POST['netname'], release_date = request.POST['reldate'], description = request.POST['desc'], rating = request.POST['rate'], duration = request.POST['duration'])
    return redirect(f'/shows/{show.id}')

def newShow(request):
    return render(request, 'index2.html')

def showInfo(request, num):
    context = {            
    'showData' : Show.objects.get(id=num),
    }
    return render(request, 'indexShows.html', context)

def editShow(request, num):
    context = {            
    'showData' : Show.objects.get(id=num),
    }
    return render(request, 'editshow.html', context)

def updateShow(request, num):
    validationErrors = Show.objects.Showvalidator(request.POST)
    print("errors from validator are printed below")
    print(validationErrors)
    if len(validationErrors) > 0:
        for key, value in validationErrors.items():
            messages.error(request, value)
        return redirect(f"/shows/{num}/edit") #make sure to make it an f string. num is the variable passed from urls that equals the numeral in showData.id, 
    show = Show.objects.get(id = num)  # show is a new variable now equal to the show we are editing
    show.title = request.POST['title'] # the following models are being equaled to the data we submitted in edit
    show.network = request.POST['netname']
    show.rating = request.POST['rate'] # the information in ' ' is pulled from the variable names given in the html editshow form
    show.duration = request.POST['duration']
    show.release_date = request.POST['reldate']
    show.description = request.POST['desc']
    show.save() #Saves the show data to the database
    return redirect(f"/shows/{num}")

def destroyShow(requst, num):
    #creating a variable name for the show and passing the show id variable num from --> html --> urls ---> views
    show2delete = Show.objects.get(id = num)
    #the command to delete is .delete()
    show2delete.delete()

    return redirect('/shows')
