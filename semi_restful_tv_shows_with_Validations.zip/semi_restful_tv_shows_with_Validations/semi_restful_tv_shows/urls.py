
from django.urls import path, include

urlpatterns = [
    path('', include('semi_restful_tv_shows_app.urls')),
]