from django.shortcuts import render, HttpResponse

def form(request):
    return render(request, "index.html")


def sent(request):
    print(f"{request.method} Request")# Post Request will appear in the cmd teriminal
    print(request.POST)#.post must be .POST or it will not work, survey results will be printed when used with this and context block below
    context = {
        'results' : request.POST#.post must be .POST or it will not work
    }#results will be the word use to pass to the html
    return render(request, "index2.html", context)