from django.shortcuts import render
from time import gmtime, strftime
from datetime import datetime

def time(request):
    print({request.method})#will tell you if it is a get, post, etc
    context = {
    "time": strftime("%Y-%m-%d %H:%M %p")
    }
    print(strftime)
    return render(request,'index.html', context)
