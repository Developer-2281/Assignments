from django.apps import AppConfig


class LoginAndRegistrationAppConfig(AppConfig):
    name = 'login_and_registration_app'
