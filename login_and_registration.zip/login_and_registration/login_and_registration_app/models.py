from django.db import models
import bcrypt
import re

# Create your models here.
class UserManager(models.Manager): #User is the variable name I gave the manager, you can name it whatever you want.
    def registrationvalidator(self, postData):
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        userMatchesRegisteredEmail = User.objects.filter(email = postData['email'])

        errors = {}
        # add keys and values to errors dictionary for each invalid field
        if len(postData['fName']) == 0:
            errors["noFirstName"] = "First Name is Required"
        elif len(postData['fName']) < 2:
            errors["firstName2char"] = "First Name must be 2 or more characters"
        if len(postData['lName']) == 0:
            errors["noLastName"] = "Last Name is Required"
        elif len(postData['lName']) < 2:
            errors["lastName2Char"] = "Last Name must be 2 or more characters"
        if len(postData['email']) == 0:
            errors["noEmail"] = "Email is Required"
        elif not EMAIL_REGEX.match(postData['email']):
            errors['invaildemail'] = "Invalid Email"
        elif len(userMatchesRegisteredEmail) > 0:
            errors['emailinuse'] = "This email is already registered"
        if len(postData['pw']) == 0:
            errors["NoPw"] = "Password is Required"
        elif len(postData['pw']) < 8:
            errors["pw8Char"] = "Password must be at least 8 characters"
        if postData['pw'] != postData['cpw']: # password and confirm password
            errors['nopwmatch'] =  "Passwords do not match"
        return errors

    def loginValidator(self, postData):
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        userMatchesRegisteredEmail = User.objects.filter(email = postData['email'])

        errors = {}
        if len(postData['email']) == 0:
            errors["noEmail"] = "Email is Required"
        elif not EMAIL_REGEX.match(postData['email']):
            errors['invaildemail'] = "Invalid Email"
        elif len(userMatchesRegisteredEmail) == 0:
            errors['emailnotregistered'] = "This email is not registered"
        else:
            if len(postData['pw']) == 0:
                errors["NoPw"] = "Password is Required"
            elif not bcrypt.checkpw(postData['pw'].encode(), userMatchesRegisteredEmail[0].password.encode()):
                errors['incorrectPw'] = "Incorrect Password"
            # encrypted email validator
            print('*****')
            print(userMatchesRegisteredEmail[0].password)
            print('*****')
            #if userMatchesRegisteredEmail[0].password != postData['pw']:
            #   errors['incorrectPw'] = "Incorrect Password"
            #above two lines are the non encrypted email validator
        return errors

class User(models.Model):

    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager() #***** Remember to add this for validations *****#


    def __str__(self):
	    return f"<Show object: {self.title} ({self.id})>"