from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('submit', views.submit),
    path('submitAuthor', views.submitAuthor),
    path('authors', views.authors),
    path('authors/<int:num>', views.authorsInfo),
    path('books/<int:num>', views.books),
    path('linkAuthor/<int:num>', views.linkAuthor),
    path('linkBook/<int:num>', views.linkBook),
]