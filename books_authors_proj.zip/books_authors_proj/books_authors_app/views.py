from django.shortcuts import render, HttpResponse, redirect
from .models import *

def index(request):
    print(Book.objects.all())
    context = {
        'bookData' : Book.objects.all(),
        'authorData' : Author.objects.all()
    }
    return render(request, 'index.html', context)

def submit(request):#always redirect on a post request. we submitted information we have to redirect.
    print(request.POST)
    Book.objects.create(title = request.POST['tName'], desc = request.POST['desc'])
    return redirect('/')

def authors(request):
    print(Author.objects.all())
    context = {
        'bookData' : Book.objects.all(),
        'authorData' : Author.objects.all()
    }
    return render(request, 'indexAuthors.html', context)
    
def submitAuthor(request):
    print(request.POST)
    Author.objects.create(first_name = request.POST['fName'], last_name = request.POST['lName'], notes = request.POST['desc'])
    return redirect('/authors')

def books(request, num):
    print(Book.objects.all())
    context = {
        'bookData' : Book.objects.get(id=num),   ##### this needs to be updated to .get(id=num)
        #bookData can now be called in the html
        'authorData' : Author.objects.all(),
    }
    return render(request, 'indexBooks.html', context)

def linkAuthor(request, num):
    book = Book.objects.get(id=num)
    author = Author.objects.get(id=request.POST['selectedAuthor'])
    author.books.add(book)
    return redirect(f'/books/{num}')

def authorsInfo(request, num):
    context = {
        'bookData' : Book.objects.all(),   ##### this needs to be updated to .get(id=num)
        #bookData can now be called in the html
        'authorData' : Author.objects.get(id=num),
    }
    return render(request, 'indexAuthors2.html', context)

    
def linkBook(request, num):
    author = Author.objects.get(id=num)
    book = Book.objects.get(id=request.POST['selectedBook'])
    book.authors_link.add(author)
    return redirect(f'/authors/{num}')
