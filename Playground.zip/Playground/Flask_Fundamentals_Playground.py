from flask import Flask, render_template  ##### added render_template! #####
app = Flask(__name__)                     
    
@app.route('/play')                           
def boxes():
    return render_template('3boxes.html')

@app.route('/play/<int:num>')     # < indicates a variable, int indicates the variable is a number(integer), num is the name I assigned my variable, and > closes off the variable.
def unlBoxes(num):     #The variable num I assigend in the route above must be listed in the function
    return render_template("unlimitedBoxes.html", times = num) ##### times is the linkage word to the html file, num indicates how many renders #####

@app.route('/play/<int:num>/<color>')
def unlBoxesColor(num,color):
    return render_template("unlimitedBoxesColor.html", times = num, hue = color)

if __name__=="__main__":
    app.run(debug=True)    